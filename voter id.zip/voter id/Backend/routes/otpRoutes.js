const express = require("express");
const router = express.Router();
const Otp = require("../models/Otp");

router.post("/send-otp", async (req, res) => {
    try {
        const { mobile } = req.body;
        if (!mobile) return res.status(400).json({ error: "Mobile number required" });

        // Delete any existing OTP for this mobile
        await Otp.deleteMany({ mobile });

        // Generate 6-digit OTP
        const otp = Math.floor(100000 + Math.random() * 900000).toString();

        // Save OTP to DB
        const newOtp = new Otp({ mobile, otp });
        await newOtp.save();

        // In real app, send OTP via SMS. Here, just log it.
        console.log(`OTP for ${mobile}: ${otp}`);

        res.status(200).json({ message: "OTP sent successfully" });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;