const express = require("express");
const router = express.Router();
const VoterApply = require("../models/VoterApply");
const VoterUpdate = require("../models/VoterUpdate");

// Get all applications
router.get("/applications", async (req, res) => {
    try {
        const applications = await VoterApply.find().sort({ createdAt: -1 });
        res.status(200).json(applications);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get all updates
router.get("/updates", async (req, res) => {
    try {
        const updates = await VoterUpdate.find().sort({ createdAt: -1 });
        res.status(200).json(updates);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Update application status
router.put("/status/:id", async (req, res) => {
    try {
        const { status } = req.body;
        await VoterApply.findByIdAndUpdate(req.params.id, { status });
        res.status(200).json({ message: "Status updated successfully" });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Update voter update status
router.put("/update-status/:id", async (req, res) => {
    try {
        const { status } = req.body;
        await VoterUpdate.findByIdAndUpdate(req.params.id, { status });
        res.status(200).json({ message: "Status updated successfully" });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Track application or update by applicationId
router.get("/track/:applicationId", async (req, res) => {
    try {
        let record = await VoterApply.findOne({ applicationId: req.params.applicationId });
        if (!record) {
            record = await VoterUpdate.findOne({ applicationId: req.params.applicationId });
        }
        if (!record) {
            return res.status(404).json({ error: "Application not found" });
        }
        res.status(200).json(record);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
