const express = require("express");
const router = express.Router();
const VoterApply = require("../models/VoterApply");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

// Ensure uploads directory exists
const uploadsDir = path.join(__dirname, "../uploads");
if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
}

// Multer config
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, uploadsDir);
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + "-" + file.originalname);
    }
});
const upload = multer({ storage });

router.post("/", upload.single("aadhaar"), async (req, res) => {
    try {
        console.log("=== Apply Route Called ===");
        console.log("Body:", req.body);
        console.log("File:", req.file);
        
        const data = req.body;
        const mobile = data.mobile;

        if (!mobile) {
            console.log("Mobile number is missing");
            return res.status(400).json({ error: "Mobile number is required" });
        }

        // Generate unique application ID
        const applicationId = "APP-" + Date.now() + "-" + Math.random().toString(36).substr(2, 9);

        // Save voter application
        const voter = new VoterApply({
            applicationId,
            ...data,
            aadhaarPath: req.file ? req.file.path : null,
            status: "Pending"
        });
        await voter.save();
        console.log("Voter application saved successfully with ID:", applicationId);
        res.status(201).json({ 
            message: "Voter Application Submitted Successfully",
            applicationId: applicationId
        });
    } catch (error) {
        console.error("=== Error in Apply Route ===");
        console.error(error);
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
