const express = require("express");
const router = express.Router();
const VoterUpdate = require("../models/VoterUpdate");

router.post("/", async (req, res) => {
    try {
        console.log("Received update data:", req.body);
        const applicationId = "VOTER-UPDATE-" + Date.now() + "-" + Math.random().toString(36).substr(2, 9);
        const update = new VoterUpdate({
            applicationId,
            ...req.body,
            status: "Pending"
        });
        await update.save();
        res.status(201).json({ 
            message: "Voter Update Submitted",
            applicationId
        });
    } catch (error) {
        console.log("Error:", error.message);
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
