const mongoose = require("mongoose");

const OtpSchema = new mongoose.Schema({
    mobile: String,
    otp: String,
    expiresAt: { type: Date, default: Date.now, expires: 300 } // expires in 5 minutes
});

module.exports = mongoose.model("Otp", OtpSchema);