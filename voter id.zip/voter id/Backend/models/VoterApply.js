const mongoose = require("mongoose");

const VoterApplySchema = new mongoose.Schema({
    applicationId: { type: String, unique: true },
    name: String,
    dob: String,
    gender: String,
    parentName: String,
    mobile: String,
    email: String,
    address: String,
    state: String,
    district: String,
    pincode: String,
    aadhaarPath: String,
    status: { type: String, default: "Pending" },
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("VoterApply", VoterApplySchema);
