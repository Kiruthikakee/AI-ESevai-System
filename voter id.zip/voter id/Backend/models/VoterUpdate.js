const mongoose = require("mongoose");

const VoterUpdateSchema = new mongoose.Schema({
    applicationId: String,
    voterId: String,
    updateType: String,
    oldValue: String,
    newValue: String,
    status: { type: String, default: "Pending" },
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("VoterUpdate", VoterUpdateSchema);
