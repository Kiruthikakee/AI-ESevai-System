const mongoose = require('mongoose');

const updateRequestSchema = new mongoose.Schema({
  applicationId: { type: String },
  aadhaarNumber: { type: String },
  updateType: { type: String },
  details: { type: mongoose.Schema.Types.Mixed },
  changes: { type: mongoose.Schema.Types.Mixed },
  status: { type: String, enum: ['Pending','Processed','Rejected'], default: 'Pending' },
  documentPaths: [{ type: String }],
}, { timestamps: true });

module.exports = mongoose.model('UpdateRequest', updateRequestSchema);
