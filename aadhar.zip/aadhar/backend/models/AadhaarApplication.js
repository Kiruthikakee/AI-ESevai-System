// ===================== IMPORTS =====================
const mongoose = require("mongoose");

// ===================== AADHAR APPLICATION SCHEMA =====================
const aadharApplicationSchema = new mongoose.Schema(
  {
    firstName: {
      type: String,
      required: true,
      trim: true,
    },

    lastName: {
      type: String,
      required: true,
      trim: true,
    },

    fatherName: {
      type: String,
      required: true,
      trim: true,
    },

    dob: {
      type: Date,
      required: true,
    },

    gender: {
      type: String,
      enum: ["Male", "Female", "Other"],
      required: true,
    },

    phone: {
      type: String,
      required: true,
      match: /^[0-9]{10}$/,
    },

    address: {
      type: String,
      required: true,
    },

    // Optional Aadhaar number (12-digit) if assigned later
    aadhaarNumber: {
      type: String,
      unique: true,
      sparse: true,
      match: /^[0-9]{12}$/,
    },

    enrollmentId: {
      type: String,
      unique: true,
      required: true,
    },

    status: {
      type: String,
      enum: ["Under Processing", "Approved", "Rejected"],
      default: "Under Processing",
    },

    documentPath: {
      type: String,
    },

    photoPath: {
      type: String,
    },
  },
  {
    timestamps: true, // adds createdAt & updatedAt
  }
);

// ===================== MODEL EXPORT =====================
module.exports = mongoose.model(
  "AadharApplication",
  aadharApplicationSchema
);
