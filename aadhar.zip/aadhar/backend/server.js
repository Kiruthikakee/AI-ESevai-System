// ===================== IMPORTS =====================
const express = require("express");
const cors = require("cors");

// ===================== APP SETUP =====================
const app = express();
const PORT = process.env.PORT || 3000;

// ===================== MONGOOSE CONNECT =====================
const mongoose = require('mongoose');
const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/campuss';

mongoose.connect(MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
  .then(() => console.log('Connected to MongoDB'))
  .catch((err) => console.error('MongoDB connection error:', err));

// ===================== MIDDLEWARE =====================
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static('uploads'));

// ===================== ROOT ROUTE =====================
app.get("/", (req, res) => {
  res.send("UIDAI Backend Server is Running");
});

const aadhaarRoutes = require('./routes/aadhaar');
app.use('/api/aadhaar', aadhaarRoutes);

// ===================== START SERVER =====================
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
