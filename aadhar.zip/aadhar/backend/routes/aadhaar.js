// ===================== IMPORTS =====================
const express = require("express");
const multer = require("multer");
const path = require("path");
const router = express.Router();

const AadharApplication = require("../models/AadhaarApplication");
const UpdateRequest = require("../models/UpdateRequest");

// ===================== MULTER CONFIGURATION =====================
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname);
  }
});

const upload = multer({ 
  storage: storage,
  fileFilter: function (req, file, cb) {
    const allowedTypes = /jpeg|jpg|png|pdf/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Only PDF, JPG, JPEG, and PNG files are allowed'));
    }
  },
  limits: { fileSize: 5 * 1024 * 1024 } // 5MB limit
});

// ===================== APPLY FOR AADHAAR =====================
// Public Route: creates a new Aadhaar application
router.post("/apply", upload.fields([{name: 'document', maxCount: 1}, {name: 'photo', maxCount: 1}]), async (req, res) => {
  try {
    console.log('[/api/aadhaar/apply] payload:', req.body);
    console.log('[/api/aadhaar/apply] file:', req.file);
    const {
      firstName,
      lastName,
      fatherName,
      dob,
      gender,
      phone,
      address,
    } = req.body;

    // Basic validation to return useful errors to client
    if (!firstName || !lastName || !fatherName || !dob || !gender || !phone || !address) {
      return res.status(400).json({ success: false, message: 'Missing required fields: firstName, lastName, fatherName, dob, gender, phone, address are required.' });
    }

    // Sanitize and validate phone number (expect 10 digits)
    const digits = String(phone).replace(/\D/g, '');
    if (digits.length !== 10) {
      return res.status(400).json({ success: false, message: 'Phone number must contain exactly 10 digits.' });
    }
    const phoneClean = digits;

    // Validate gender
    const allowedGenders = ['Male', 'Female', 'Other'];
    if (!allowedGenders.includes(gender)) {
      return res.status(400).json({ success: false, message: 'Gender must be one of: Male, Female, Other.' });
    }

    // Validate DOB
    const dobDate = new Date(dob);
    if (isNaN(dobDate.getTime())) {
      return res.status(400).json({ success: false, message: 'Invalid date of birth.' });
    }

    // Generate Enrollment ID
    const enrollmentId = "EID" + Date.now();

    const newApplication = new AadharApplication({
      firstName,
      lastName,
      fatherName,
      dob: dobDate,
      gender,
      phone: phoneClean,
      address,
      enrollmentId,
      documentPath: req.files?.document?.[0]?.path || null,
      photoPath: req.files?.photo?.[0]?.path || null,
    });

    await newApplication.save();

    res.status(201).json({
      success: true,
      message: "Aadhaar application submitted successfully",
      enrollmentId,
    });
  } catch (error) {
    console.error('Error in /api/aadhaar/apply:', error);
    res.status(500).json({
      success: false,
      message: "Failed to submit Aadhaar application",
      error: error.message,
    });
  }
});

// ===================== CHECK APPLICATION STATUS =====================
// Public Route
router.post("/status", async (req, res) => {
  try {
    const { enrollmentId, applicationId } = req.body;
    const idToSearch = applicationId || enrollmentId;

    console.log('[/api/aadhaar/status] Incoming body:', req.body);
    console.log('[/api/aadhaar/status] Keys:', Object.keys(req.body));
    console.log('[/api/aadhaar/status] enrollmentId value:', enrollmentId, 'applicationId value:', applicationId);
    console.log('[/api/aadhaar/status] Searching for ID:', idToSearch);

    // Build queries explicitly for better visibility when debugging
    const queryForApplication = { $or: [{ enrollmentId: idToSearch }, { applicationId: idToSearch }] };
    console.log('[/api/aadhaar/status] Query for AadharApplication:', JSON.stringify(queryForApplication));

    let record = await AadharApplication.findOne(queryForApplication);
    let type = "application";

    if (!record) {
      record = await UpdateRequest.findOne({ $or: [{ aadhaarNumber: idToSearch }, { applicationId: idToSearch }] });
      type = "update";
    }

    if (!record) {
      console.log('[/api/aadhaar/status] No record found for:', idToSearch);
      // Return debug info temporarily to help diagnose search mismatches
      return res.status(404).json({
        success: false,
        message: "Application not found",
        debug: {
          body: req.body,
          searchId: idToSearch,
          applicationQuery: queryForApplication
        }
      });
    }

    console.log('[/api/aadhaar/status] Found record type:', type, 'id:', record._id, 'appId/enroll:', (record.applicationId || record.enrollmentId), 'status:', record.status);

    res.json({
      success: true,
      id: record.enrollmentId || record.applicationId,
      type: type,
      status: record.status,
      submittedOn: record.createdAt,
      firstName: record.firstName,
      lastName: record.lastName,
      fatherName: record.fatherName,
      dob: record.dob,
      gender: record.gender,
      address: record.address,
      phone: record.phone,
      photoPath: record.photoPath
    });
  } catch (error) {
    console.error('[/api/aadhaar/status] Error:', error);
    res.status(500).json({
      success: false,
      message: "Error fetching application status",
      error: error.message,
    });
  }
});

// ===================== SUBMIT UPDATE REQUEST =====================
// Public Route: stores update requests for manual processing
router.post('/update', upload.array('documents', 5), async (req, res) => {
  try {
    console.log('[/api/aadhaar/update] payload:', req.body);
    console.log('[/api/aadhaar/update] files:', req.files);
    const payload = req.body;
    const aadhaarNumber = payload.aadhaar || payload.enrollmentId || null;

    // Build a `changes` object containing only provided (non-empty) fields
    const keysToCheck = ['fullname','dob','gender','address','city','state','pincode','mobile','email','otherDetails'];
    const changes = {};
    keysToCheck.forEach(k => {
      if (payload[k] !== undefined && String(payload[k]).trim() !== '') {
        changes[k] = payload[k];
      }
    });

    // Create an update request record (audit trail)
    const applicationId = "AADHAAR-UPDATE-" + Date.now();
    const update = new UpdateRequest({
      applicationId,
      aadhaarNumber,
      updateType: payload.updateType || 'other',
      details: payload,
      changes,
      documentPaths: req.files ? req.files.map(file => file.path) : [],
    });

    await update.save();

    // Attempt to apply changes immediately to an existing AadhaarApplication when possible
    let applied = false;
    let application = null;
    if (aadhaarNumber) {
      // Try multiple ways to locate the application: enrollmentId, phone, or aadhaarNumber
      application = await AadharApplication.findOne({
        $or: [
          { enrollmentId: aadhaarNumber },
          { phone: aadhaarNumber },
          { aadhaarNumber: aadhaarNumber }
        ]
      });

      if (application) {
        // Apply known fields
        if (payload.fullname) {
          const parts = payload.fullname.trim().split(/\s+/);
          application.firstName = parts.shift() || application.firstName;
          application.lastName = parts.join(' ') || application.lastName;
        }
        if (payload.dob) application.dob = payload.dob;
        if (payload.gender) application.gender = payload.gender;
        if (payload.address) application.address = payload.address;
        if (payload.city || payload.state || payload.pincode) {
          // append or update address with structured parts
          const city = payload.city ? `, ${payload.city}` : '';
          const state = payload.state ? `, ${payload.state}` : '';
          const pincode = payload.pincode ? ` - ${payload.pincode}` : '';
          application.address = (payload.address || application.address) + city + state + pincode;
        }
        if (payload.mobile) application.phone = payload.mobile;

        // If user provided a 12-digit aadhaar value, save it to the application record
        if (/^[0-9]{12}$/.test(aadhaarNumber)) {
          application.aadhaarNumber = aadhaarNumber;
        }

        await application.save();
        applied = true;
      }
    }

    res.json({ success: true, message: 'Update request stored', applicationId, applied, changes });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to store update request', error: err.message });
  }
});

// ===================== GET ALL APPLICATIONS & UPDATE REQUESTS (ADMIN) =====================
// Admin Route: fetch all applications and update requests
router.get("/admin/all", async (req, res) => {
  try {
    const applications = await AadharApplication.find().sort({ createdAt: -1 });
    const updateRequests = await UpdateRequest.find().sort({ createdAt: -1 });

    res.json({
      success: true,
      applications,
      updateRequests,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error fetching data",
      error: error.message,
    });
  }
});

// ===================== UPDATE APPLICATION STATUS (ADMIN) =====================
// Admin Route: update application status
router.put("/admin/application/:id/status", async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    if (!["Under Processing", "Approved", "Rejected"].includes(status)) {
      return res.status(400).json({
        success: false,
        message: "Invalid status. Must be: Under Processing, Approved, or Rejected",
      });
    }

    const application = await AadharApplication.findByIdAndUpdate(
      id,
      { status },
      { new: true }
    );

    if (!application) {
      return res.status(404).json({
        success: false,
        message: "Application not found",
      });
    }

    res.json({
      success: true,
      message: "Application status updated",
      application,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error updating status",
      error: error.message,
    });
  }
});

// ===================== UPDATE REQUEST STATUS (ADMIN) =====================
// Admin Route: update update request status
router.put("/admin/update-request/:id/status", async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    if (!["Pending", "Processed", "Rejected"].includes(status)) {
      return res.status(400).json({
        success: false,
        message: "Invalid status. Must be: Pending, Processed, or Rejected",
      });
    }

    const updateRequest = await UpdateRequest.findByIdAndUpdate(
      id,
      { status },
      { new: true }
    );

    if (!updateRequest) {
      return res.status(404).json({
        success: false,
        message: "Update request not found",
      });
    }

    res.json({
      success: true,
      message: "Update request status updated",
      updateRequest,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error updating status",
      error: error.message,
    });
  }
});

// ===================== EXPORT ROUTER =====================
module.exports = router;
