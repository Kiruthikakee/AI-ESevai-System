const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const panRoutes = require("./routes/panRoutes");

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

mongoose.connect("mongodb://127.0.0.1:27017/panDB")
  .then(() => console.log("MongoDB connected"))
  .catch(err => console.log(err));

app.use("/api/pan", panRoutes);

app.listen(5000, () => {
  console.log("Server running on port 5000");
});

