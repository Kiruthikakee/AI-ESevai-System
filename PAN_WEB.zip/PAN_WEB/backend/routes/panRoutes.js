const express = require("express");
const multer = require("multer");
const path = require("path");
const router = express.Router();
const controller = require("../controllers/panController");

// ================= MULTER CONFIGURATION =================
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname);
  }
});

const upload = multer({ 
  storage: storage,
  fileFilter: function (req, file, cb) {
    const allowedTypes = /jpeg|jpg|png|pdf/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Only PDF, JPG, JPEG, and PNG files are allowed'));
    }
  },
  limits: { fileSize: 5 * 1024 * 1024 }
});

// ================= PAN =================
router.post("/apply", upload.array('documents', 5), controller.applyPan);
router.post("/track", controller.trackPan);

// ================= OTP =================
router.post("/send-otp", controller.sendOtp);
router.post("/verify-otp", controller.verifyOtp);

// ================= PAYMENT =================
router.post("/payment/initiate", controller.initiatePayment);
router.post("/payment/success", controller.paymentSuccess);
router.post("/payment/failure", controller.paymentFailure);

// ================= OTHER SERVICES =================
router.post("/change", upload.array('documents', 5), controller.changePan);
router.post("/correction", upload.array('documents', 5), controller.correctionPan);
// router.post("/download", controller.downloadPan);
// router.post("/reprint", controller.reprintPan);
// router.post("/address-update", controller.updateAddress);

// ================= ADMIN =================
router.get("/admin/applications", controller.getAllApplications);
router.post("/admin/update-status", controller.updateStatus);

module.exports = router;
