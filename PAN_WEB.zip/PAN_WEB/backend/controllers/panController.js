// ================= IMPORTS =================
const PanApplication = require("../models/PanApplication");
const ChangeRequest = require("../models/ChangeRequest");

// ================= UTILITY =================
function generateOTP() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// ================= APPLY PAN =================
exports.applyPan = async (req, res) => {
  try {
    const applicationId = "PAN" + Date.now();

    const data = await PanApplication.create({
      ...req.body,
      applicationId,
      status: "APPLIED",
      documentPaths: req.files ? req.files.map(file => file.path) : []
    });

    res.json({
      message: "PAN Application Submitted Successfully",
      applicationId
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// ================= TRACK PAN =================
exports.trackPan = async (req, res) => {
  try {
    const { applicationId } = req.body;

    // First try to find in PanApplication
    let data = await PanApplication.findOne({ applicationId });
    let type = "PAN_APPLICATION";

    // If not found, try ChangeRequest
    if (!data) {
      data = await ChangeRequest.findOne({ _id: applicationId });
      type = "CHANGE_REQUEST";
    }

    if (!data) {
      return res.status(404).json({ message: "Application not found" });
    }

    res.json({
      id: data.applicationId || data._id,
      status: data.status,
      applicantName: data.applicantName || data.pan || "N/A",
      fatherName: data.fatherName,
      dob: data.dob,
      type: type
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// ================= CHANGE / CORRECTION =================
exports.changePan = async (req, res) => {
  try {
    const data = await ChangeRequest.create({
      ...req.body,
      documentPaths: req.files ? req.files.map(file => file.path) : []
    });
    res.json({ message: "Change Request Submitted", data });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// ================= OTP SEND =================
exports.sendOtp = async (req, res) => {
  try {
    const { applicationId } = req.body;

    const otp = generateOTP();
    const expiry = new Date(Date.now() + 5 * 60 * 1000);

    await PanApplication.updateOne(
      { applicationId },
      { otp, otpExpiry: expiry }
    );

    console.log("🔐 OTP (Demo):", otp);

    res.json({ message: "OTP sent to registered mobile number" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// ================= OTP VERIFY =================
exports.verifyOtp = async (req, res) => {
  try {
    const { applicationId, otp } = req.body;

    const data = await PanApplication.findOne({ applicationId });

    if (!data) {
      return res.status(404).json({ message: "Application not found" });
    }

    if (data.otp !== otp) {
      return res.status(400).json({ message: "Invalid OTP" });
    }

    if (data.otpExpiry < new Date()) {
      return res.status(400).json({ message: "OTP Expired" });
    }

    data.otpVerified = true;
    data.status = "VERIFIED";
    await data.save();

    res.json({ message: "OTP Verified Successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// ================= PAYMENT =================
exports.initiatePayment = async (req, res) => {
  try {
    const { applicationId, amount } = req.body;

    const transactionId = "TXN" + Date.now();

    await PanApplication.updateOne(
      { applicationId },
      {
        payment: {
          amount,
          status: "INITIATED",
          transactionId
        }
      }
    );

    res.json({
      message: "Payment Initiated",
      transactionId,
      amount
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.paymentSuccess = async (req, res) => {
  try {
    const { applicationId, mode } = req.body;

    await PanApplication.updateOne(
      { applicationId },
      {
        "payment.status": "SUCCESS",
        "payment.mode": mode,
        status: "APPROVED"
      }
    );

    res.json({ message: "Payment Successful" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.paymentFailure = async (req, res) => {
  try {
    const { applicationId } = req.body;

    await PanApplication.updateOne(
      { applicationId },
      { "payment.status": "FAILED" }
    );

    res.json({ message: "Payment Failed" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// ================= ADMIN =================
exports.getAllApplications = async (req, res) => {
  try {
    // Get all PAN applications
    const applications = await PanApplication.find();
    const applicationsWithType = applications.map(app => ({
      ...app.toObject(),
      type: "PAN_APPLICATION"
    }));

    // Get all change requests
    const changeRequests = await ChangeRequest.find();
    const changeRequestsWithType = changeRequests.map(req => ({
      ...req.toObject(),
      type: "CHANGE_REQUEST"
    }));

    // Combine both
    const allRequests = [...applicationsWithType, ...changeRequestsWithType];
    res.json(allRequests);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.updateStatus = async (req, res) => {
  try {
    const { applicationId, status, type } = req.body;

    if (type === "CHANGE_REQUEST") {
      // Update in ChangeRequest collection
      await ChangeRequest.updateOne(
        { _id: applicationId },
        { status }
      );
    } else {
      // Update in PanApplication collection
      await PanApplication.updateOne(
        { applicationId },
        { status }
      );
    }

    res.json({ message: "Status Updated Successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
exports.correctionPan = async (req, res) => {
  try {
    const applicationId = "PAN-UPDATE-" + Date.now();

    await ChangeRequest.create({
      ...req.body,
      applicationId,
      status: "SUBMITTED",
      documentPaths: req.files ? req.files.map(file => file.path) : []
    });

    res.json({
      message: "PAN Correction Submitted Successfully",
      applicationId
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
