const mongoose = require("mongoose");

const panSchema = new mongoose.Schema({
  applicantName: String,
  fatherName: String,
  dob: String,
  citizenship: String,
  mobile: String,
  email: String,
  address: String,
  applicationId: String,
  status: { type: String, default: "SUBMITTED" },
  otp: String,
  otpExpiry: Date,
  otpVerified: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now },
  documentPaths: [{ type: String }],
  payment: {
    amount: Number,
    mode: String,
    status: { type: String, default: "PENDING" },
    transactionId: String
  }
});

module.exports = mongoose.model("PanApplication", panSchema);
