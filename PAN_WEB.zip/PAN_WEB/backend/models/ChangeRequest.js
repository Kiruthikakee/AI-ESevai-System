const mongoose = require("mongoose");

module.exports = mongoose.model("ChangeRequest", {
  pan: String,
  changeType: String,
  dob: String,
  mobile: String,
  email: String,
  status: { type: String, default: "UNDER PROCESS" },
  documentPaths: [{ type: String }]
});
